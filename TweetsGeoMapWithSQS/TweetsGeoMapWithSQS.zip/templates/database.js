"use strict";

let tweetDB = {
	url: ""
};

module.exports = tweetDB;
