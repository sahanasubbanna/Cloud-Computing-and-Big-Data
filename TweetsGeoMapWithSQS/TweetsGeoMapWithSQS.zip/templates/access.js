"use strict";

let twitterKeys = {
	consumerKey: "",
	consumerSecret: "",
	callbackURL: "", //Optional
	accessToken: "",
	accessTokenSecret: ""
}

let awsKeys = {
  accessKey = "",
  accessKeySecret = ""
}

module.exports = { twitterKeys, awsKeys };
