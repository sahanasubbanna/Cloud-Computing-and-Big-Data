"use strict";

var tweetDB = {
	url: ""
};

module.exports = tweetDB;