"use strict";

//Keys for sahanasubbanna
var twitterKeys = {
	consumerKey: "K5tLW4eEGwDxePxtJ7ex8Yiew",
	consumerSecret: "OtfNRyqI1QeAUK36OVMyfzovjMQ0oiKJ9BdKEmziA6Vcp8QlLI",
	callbackURL: "", //Optional
	accessToken: "142256803-lTcoo8I8ABDNCWg25mqlYj6cdRtWuN3YgUWMVWeA",
	accessTokenSecret: "Fkf8YhwDeiumiW7p1DeYhL3YpY6V1k6xcGmlG9Gi6UvHY"
};


//Keys for kirk/kirk123
var awsKeys = {
	accessKey: "AKIAJDFFUPB4XZFEA6EA",
	accessKeySecret: "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"
};

var googleMapsKeys = {
	accessKey: "AIzaSyCsnqL6vjQkNBaK9BEpqwwvhBRaSr15Ckk"
};

var alchemyKeys = {
	// sentimentAnalysisKey: "472cf213e882977a3ce2fe83acc8b4d1b678bbe7"
	sentimentAnalysisKey: "7389c7391c3ab05f316cec9e8b352ae7c11754e4"
}

module.exports = { twitterKeys: twitterKeys, awsKeys:awsKeys, googleMapsKeys:googleMapsKeys, alchemyKeys:alchemyKeys };

